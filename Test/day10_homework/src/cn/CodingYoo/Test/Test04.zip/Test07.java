package cn.CodingYoo.Test;
/*
 *  @author:  CodingYoo
 *  date:     8/1/2020  5:26 PM Sat
 *  project:  itheimaHomework
 *  github:   https://github.com/CodingYoo
 *  from  那时还是个菜鸟
 * 代码功能要求如下

1. 定义手机类Phone包含三个成员（名称：name，价格：price，信息：message），满参构造以及get/set方法

2. 定义测试类Test，完成以下要求

	1. 定义filter(ArrayList\<Phone>, double price){}方法

		要求：遍历list集合，将list集合中价格大于参数price的元素存入到另一个ArrayList\<Phone>中并返回

	2. 在main方法中完成以下要求

		1. 创建并初始化3个Phone对象
		2. 创建一个ArrList\<Phone> listPhone，将上边3个Phone对象添加到listPhone中
		3. 调用filter方法传入listPhone和2000并接受返回值，根据接受返回的list集合输出所有元素信息
 */

public class Test07 {
    public static void main(String[] args) {

    }
}
